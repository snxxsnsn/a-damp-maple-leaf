---
title: /contact
layout: page
permalink: /contact
---

# Get in touch?

<form>
  <input type="text" id="name" name="name" placeholder="name:" autocomplete="off">
  <input type="text" id="email" name="email" placeholder="email:" autocomplete="off">
  <textarea rows="5" id="message" name="message" placeholder="message:" autocomplete="off"></textarea>
  <input type="submit" value="[ submit ]">
</form>

<br /><br />(This is a demo site, the form doesn't work - If you want to implement a form on your site, you need an external service)
